---
name: Bug
about: Algo não funciona como esperado
labels: bug
---
**O que aconteceu?**

**Como reproduzir**
1.

**O que você esperava?**
