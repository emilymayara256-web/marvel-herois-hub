---
name: Nova funcionalidade
about: Sugira uma melhoria
labels: enhancement
---
**Qual problema isso resolve?**

**Como você imagina a solução?**
