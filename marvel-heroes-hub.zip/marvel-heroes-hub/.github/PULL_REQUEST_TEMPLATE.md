## O que mudou
<!-- Resuma em 1-2 frases. -->

## Issue relacionada
Closes #

## Checklist
- [ ] `npm test` passa
- [ ] Testei no navegador (`npm start`)
- [ ] Atualizei README/CHANGELOG, se preciso
