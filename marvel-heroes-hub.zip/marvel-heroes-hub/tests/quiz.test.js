import { test } from 'node:test';
import assert from 'node:assert/strict';
import { perguntas } from '../js/questions.js';
import { pontuar, mensagemFinal } from '../js/quiz-logic.js';

test('perguntas: cada uma tem 4 opções e gabarito válido', () => {
  for (const p of perguntas) {
    assert.equal(p.opcoes.length, 4);
    assert.ok(p.correta >= 0 && p.correta < p.opcoes.length);
  }
});

test('pontuar conta acertos e calcula percentual', () => {
  const certas = perguntas.map((p) => p.correta);
  assert.deepEqual(pontuar(perguntas, certas), { acertos: perguntas.length, total: perguntas.length, percentual: 100 });
  assert.equal(pontuar(perguntas, []).acertos, 0);
});

test('mensagemFinal muda conforme o desempenho', () => {
  assert.match(mensagemFinal(100), /Perfeito/);
  assert.match(mensagemFinal(70), /Muito bem/);
  assert.match(mensagemFinal(10), /reler/);
});
