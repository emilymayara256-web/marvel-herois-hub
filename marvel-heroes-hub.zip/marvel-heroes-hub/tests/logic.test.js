import { test } from 'node:test';
import assert from 'node:assert/strict';
import { heroes } from '../js/heroes.js';
import { STATS, filterHeroes, listTimes, poderTotal, ranking, comparar, iniciais, contraste } from '../js/logic.js';

const por = (id) => heroes.find((h) => h.id === id);

test('dados: ids únicos e atributos entre 1 e 10', () => {
  assert.equal(new Set(heroes.map((h) => h.id)).size, heroes.length);
  for (const h of heroes) for (const k of STATS) assert.ok(h.stats[k] >= 1 && h.stats[k] <= 10, `${h.id}.${k}`);
});

test('filterHeroes: por time', () => {
  const xmen = filterHeroes(heroes, { time: 'X-Men' });
  assert.deepEqual(xmen.map((h) => h.id), ['wolverine', 'tempestade']);
});

test('filterHeroes: busca ignora acento e caixa, e acha pela identidade civil', () => {
  assert.equal(filterHeroes(heroes, { busca: 'VIUVA' })[0].id, 'viuva-negra');
  assert.equal(filterHeroes(heroes, { busca: 'peter' })[0].id, 'homem-aranha');
});

test('filterHeroes: sem resultado devolve lista vazia', () => {
  assert.deepEqual(filterHeroes(heroes, { busca: 'zzz' }), []);
});

test('listTimes: sem repetição e em ordem alfabética', () => {
  const t = listTimes(heroes);
  assert.deepEqual(t, [...t].sort((a, b) => a.localeCompare(b, 'pt')));
  assert.equal(new Set(t).size, t.length);
});

test('poderTotal soma os cinco atributos', () => {
  assert.equal(poderTotal(por('thor')), 43);
});

test('ranking: ordena do mais forte ao mais fraco e respeita n', () => {
  const r = ranking(heroes, 3);
  assert.equal(r.length, 3);
  assert.deepEqual(r.map((h) => h.id), ['thor', 'capita-marvel', 'hulk']);
});

test('comparar: identifica vencedor por atributo e no total', () => {
  const r = comparar(por('thor'), por('viuva-negra'));
  assert.equal(r.vencedor, 'a');
  assert.equal(r.linhas.find((l) => l.stat === 'forca').vencedor, 'a');
  assert.equal(comparar(por('thor'), por('thor')).vencedor, 'empate');
});

test('iniciais e contraste', () => {
  assert.equal(iniciais('Homem-Aranha'), 'HA');
  assert.equal(iniciais('Thor'), 'T');
  assert.equal(contraste('#f5c518'), '#000');
  assert.equal(contraste('#28408f'), '#fff');
});
