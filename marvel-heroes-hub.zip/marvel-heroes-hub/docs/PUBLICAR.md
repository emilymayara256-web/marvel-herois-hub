# Publicando no GitHub (seguindo o roteiro do tutorial)

Este repositório já vem com **histórico completo de commits**. Por isso o envio é feito por `git push` (e não por *Upload files*), para preservar cada commit.

## 0. Personalize antes de enviar

Troque o marcador `SEU-USUARIO` pelo seu usuário do GitHub e `SEU NOME` na licença:

```bash
grep -rl "SEU-USUARIO" . --exclude-dir=.git | xargs sed -i 's/SEU-USUARIO/seu-usuario-real/g'
sed -i 's/SEU NOME/Seu Nome Completo/' LICENSE
git commit -am "docs: personaliza usuário e licença"
```

Os commits vêm com autor de exemplo. Para assinar todos como você (faça **antes** do primeiro push):

```bash
git filter-branch -f --env-filter '
export GIT_AUTHOR_NAME="Seu Nome"  GIT_AUTHOR_EMAIL="seu-email-do-github@exemplo.com"
export GIT_COMMITTER_NAME="Seu Nome" GIT_COMMITTER_EMAIL="seu-email-do-github@exemplo.com"
' --tag-name-filter cat -- --all
```

O e-mail precisa estar na sua conta do GitHub para os commits contarem no gráfico de contribuições.

## 1. Criar o repositório (Parte 1 do tutorial)

No GitHub: **New repository** → nome `marvel-heroes-hub` → **Public** → **não** marque README, .gitignore nem license (o projeto já tem).

## 2. Ativar o Pages (Parte 3, antes de enviar o código)

**Settings > Pages > Build and deployment > Source > GitHub Actions.**

## 3. Enviar o projeto (Parte 4)

```bash
git remote add origin https://github.com/SEU-USUARIO/marvel-heroes-hub.git
git push -u origin main --tags
```

## 4. Primeira execução (Parte 5)

Aba **Actions**: confira `test`, `build` e `deploy` verdes. O site fica em `https://SEU-USUARIO.github.io/marvel-heroes-hub/`.

## 5. Mostre o fluxo de trabalho (Partes 6 a 9)

Faça ao menos uma mudança real pelo fluxo completo para o repositório exibir Issues e Pull Requests fechados:

1. **Issue:** *Mudar a cor de destaque do site*.
2. **Branch** `feature/cor-de-destaque`: edite `--ouro` em `css/base.css` e use **Create a new branch for this commit and start a pull request**.
3. **Pull Request:** título claro, descrição `Closes #1`, aguarde **All checks have passed**.
4. **Merge pull request** → **Delete branch** → acompanhe o deploy → a Issue fecha sozinha.

## 6. Proteger a main (Parte 10)

**Settings > Rules > Rulesets > New branch ruleset:** nome `proteger-main`, *Enforcement* **Active**, alvo **Include default branch**, marque **Require a pull request before merging** e **Require status checks to pass** (adicione `test`).

## 7. Release (Parte 11)

**Releases > Create a new release** → *Choose a tag* digite `v1.0.0` e **Create new tag** → título `v1.0.0` → **Generate release notes** → **Publish release**.
(Se já enviou as tags no passo 3, escolha a tag `v1.0.0` existente.)

## 8. Deixe o repositório atraente

- **About** (engrenagem na página inicial): descrição, site (`github.io`) e topics: `marvel`, `javascript`, `github-actions`, `github-pages`, `portfolio`.
- Fixe o repositório no seu perfil (**Customize your pins**).

## Problemas comuns

- **Actions vazia:** o workflow precisa estar em `.github/workflows/ci-cd.yml`.
- **Deploy falha por permissão:** falta o passo 2. Ative e use **Actions > CI/CD > Run workflow**.
- **Vídeo não toca no README:** o GitHub abre o `.mp4` em outra página ao clicar na imagem; no site publicado os vídeos tocam na seção *Vídeos*.
