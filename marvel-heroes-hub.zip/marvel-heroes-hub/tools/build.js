// Copia apenas o que vai ao ar para ./dist (usado pelo job "build" do workflow).
import { cpSync, existsSync, mkdirSync, rmSync } from 'node:fs';

rmSync('dist', { recursive: true, force: true });
mkdirSync('dist');
for (const item of ['index.html', 'quiz.html', 'css', 'js', 'slides', 'assets']) {
  if (existsSync(item)) cpSync(item, `dist/${item}`, { recursive: true });
}
console.log('Build pronto em ./dist');
