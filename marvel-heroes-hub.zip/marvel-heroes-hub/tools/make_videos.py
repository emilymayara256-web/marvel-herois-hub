#!/usr/bin/env python3
"""Gera os vídeos ilustrativos do projeto (Pillow + ffmpeg).

Uso: python3 tools/make_videos.py
Saída: assets/videos/intro.mp4, pipeline.mp4 e seus pôsteres .jpg
"""
import glob
import math
import subprocess
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1280, 720, 24
OUT = Path(__file__).resolve().parent.parent / "assets" / "videos"
INK, PANEL, RED, GOLD, WHITE, GREEN = (14, 17, 36), (29, 36, 71), (232, 54, 47), (255, 199, 44), (242, 244, 255), (63, 185, 80)
HEROES = [("HF", (232, 87, 42)), ("CA", (40, 64, 143)), ("TH", (245, 197, 24)), ("HU", (63, 157, 74)),
          ("HA", (214, 40, 57)), ("PN", (107, 75, 208)), ("DE", (31, 163, 184)), ("CM", (222, 61, 131))]
SANS = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def _display_font():
    for pattern in ("/usr/share/fonts/**/Bangers*.ttf", "/usr/share/fonts/**/Anton*.ttf"):
        found = glob.glob(pattern, recursive=True)
        if found:
            return found[0]
    return SANS


DISPLAY = _display_font()


@lru_cache(None)
def display(size):
    return ImageFont.truetype(DISPLAY, max(8, int(size)))


@lru_cache(None)
def sans(size):
    return ImageFont.truetype(SANS, max(8, int(size)))


def ease(t):
    t = min(max(t, 0), 1)
    return 1 - (1 - t) ** 3


def pop(t):  # "back ease-out": passa um pouco do alvo e assenta
    t = min(max(t, 0), 1)
    return 1 + 2.70158 * (t - 1) ** 3 + 1.70158 * (t - 1) ** 2


def mix(color, t):  # de INK até a cor
    return tuple(int(a + (b - a) * t) for a, b in zip(INK, color))


def halftone():
    im = Image.new("RGB", (W, H), INK)
    d = ImageDraw.Draw(im)
    for y in range(0, H, 26):
        for x in range(0, W, 26):
            r = 9 * (1 - math.hypot(W - x, H - y) / 900)
            if r > 0.8:
                d.ellipse((x - r, y - r, x + r, y + r), fill=(34, 42, 84))
    return im


BG = halftone()


def text(d, xy, s, font, fill=WHITE, stroke=0, anchor="mm"):
    d.text(xy, s, font=font, fill=fill, stroke_width=stroke, stroke_fill=(0, 0, 0), anchor=anchor)


def on_color(c):
    return (0, 0, 0) if 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2] > 150 else WHITE


def intro(t):
    im = BG.copy()
    d = ImageDraw.Draw(im)
    size = 175 * pop(t / 0.9)
    text(d, (W / 2 + 9, 209), "HEROES HUB", display(size), RED, 8)
    text(d, (W / 2, 200), "HEROES HUB", display(size), GOLD, 8)
    text(d, (W / 2, 330), "Projeto de portfólio feito com HTML, CSS e JavaScript", sans(28), mix(WHITE, ease((t - 0.9) / 0.8)))
    for k, (ini, cor) in enumerate(HEROES):
        r = 56 * pop((t - 1.4 - 0.22 * k) / 0.5)
        if r > 1:
            x, y = W / 2 + (k - 3.5) * 130, 450
            d.ellipse((x - r, y - r, x + r, y + r), fill=cor, outline=(0, 0, 0), width=5)
            text(d, (x, y), ini, display(r * 0.95), on_color(cor))
    text(d, (W / 2, 585), "12 heróis · comparador · quiz · esteira CI/CD", sans(32), mix(WHITE, ease((t - 4) / 0.8)))
    a = ease((t - 6) / 0.7)
    if a > 0:
        y = 650 + (1 - a) * 30
        d.rounded_rectangle((300, y - 30, 980, y + 30), 12, fill=mix(GOLD, a), outline=(0, 0, 0), width=4)
        text(d, (W / 2, y), "github.com/SEU-USUARIO/marvel-heroes-hub", sans(26), mix((0, 0, 0), a))
    return im


STEPS = [("Issue", "registra a tarefa"), ("Branch", "feature/cor-do-quiz"), ("Commit", "mensagem clara"), ("Pull Request", "Closes #1"),
         ("Testes", "npm test no Actions"), ("Merge", "checks verdes"), ("Deploy", "GitHub Pages"), ("Release", "tag v1.0.0")]


def pipeline(t):
    im = BG.copy()
    d = ImageDraw.Draw(im)
    text(d, (W / 2, 95), "DA ISSUE AO RELEASE", display(96), GOLD, 7)
    cw, ch, gap = 250, 150, 30
    x0 = (W - 4 * cw - 3 * gap) / 2
    for k, (nome, sub) in enumerate(STEPS):
        a = ease((t - 1 - 1.0 * k) / 0.5)
        x, y = x0 + (k % 4) * (cw + gap), 200 + (k // 4) * 220
        d.rectangle((x + 8, y + 8, x + cw + 8, y + ch + 8), fill=mix(GREEN if k == 7 else RED, a))
        d.rectangle((x, y, x + cw, y + ch), fill=PANEL, outline=(0, 0, 0), width=4)
        d.ellipse((x + 14, y + 14, x + 54, y + 54), fill=mix(GOLD, 0.35 + 0.65 * a), outline=(0, 0, 0), width=3)
        text(d, (x + 34, y + 34), str(k + 1), sans(22), (0, 0, 0))
        text(d, (x + cw / 2, y + 85), nome, sans(30), WHITE)
        text(d, (x + cw / 2, y + 122), sub, sans(17), (170, 179, 224))
        if a > 0.6:
            text(d, (x + cw - 30, y + 34), "✓", sans(34), GREEN)
        if k % 4 < 3:
            ax, ay = x + cw + 5, y + ch / 2
            d.polygon([(ax, ay - 9), (ax + 20, ay), (ax, ay + 9)], fill=mix(GOLD, 0.3 + 0.7 * ease((t - 1 - 1.0 * k - 0.5) / 0.4)))
    b = ease((t - 9.7) / 0.6)
    if b > 0:
        d.rounded_rectangle((330, 625, 950, 690), 14, fill=mix(GREEN, b), outline=(0, 0, 0), width=4)
        text(d, (W / 2, 658), "v1.0.0 publicada e no ar", sans(30), mix((0, 0, 0), b))
    return im


def encode(name, frame_fn, seconds):
    OUT.mkdir(parents=True, exist_ok=True)
    dest = OUT / f"{name}.mp4"
    total = seconds * FPS
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
           "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "24", "-movflags", "+faststart", str(dest)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(total):
        frame = frame_fn(i / FPS)
        if i == int(total * 0.8):
            frame.save(OUT / f"{name}.jpg", quality=84)
        proc.stdin.write(frame.tobytes())
    proc.stdin.close()
    proc.wait()
    print("gerado:", dest)


if __name__ == "__main__":
    encode("intro", intro, 9)
    encode("pipeline", pipeline, 12)
