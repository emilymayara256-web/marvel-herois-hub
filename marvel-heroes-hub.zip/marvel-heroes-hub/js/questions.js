export const perguntas = [
  { pergunta: 'Qual é a identidade civil do Homem de Ferro?', opcoes: ['Steve Rogers', 'Tony Stark', 'Bruce Banner', 'Peter Parker'], correta: 1 },
  { pergunta: 'Como se chama o martelo de Thor?', opcoes: ['Mjölnir', 'Stormbreaker', 'Gungnir', 'Vibranium'], correta: 0 },
  { pergunta: 'Qual metal fictício é a base da riqueza de Wakanda?', opcoes: ['Adamantium', 'Uru', 'Vibranium', 'Titânio'], correta: 2 },
  { pergunta: 'Qual é o nome da escola de Charles Xavier?', opcoes: ['Academia Avengers', 'Escola para Jovens Superdotados', 'Sanctum Sanctorum', 'Edifício Baxter'], correta: 1 },
  { pergunta: 'Quantas Joias (ou Pedras) do Infinito existem nos quadrinhos?', opcoes: ['4', '5', '6', '7'], correta: 2 },
  { pergunta: 'Em qual revista o Homem-Aranha estreou, em 1962?', opcoes: ['Amazing Fantasy #15', 'Fantastic Four #1', 'Strange Tales #110', 'X-Men #1'], correta: 0 }
];
