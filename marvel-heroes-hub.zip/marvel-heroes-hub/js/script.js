import { heroes } from './heroes.js';
import { filterHeroes, listTimes, poderTotal, iniciais, contraste, STATS, ROTULOS } from './logic.js';

const $ = (seletor) => document.querySelector(seletor);
const estado = { time: 'todos', busca: '' };

const selo = (h) => `<span class="selo" style="--cor:${h.cor};--on:${contraste(h.cor)}" aria-hidden="true">${iniciais(h.nome)}</span>`;

function renderTimes() {
  const times = ['todos', ...listTimes(heroes)];
  $('#times').innerHTML = times
    .map((t) => `<button type="button" data-time="${t}" aria-pressed="${t === estado.time}">${t === 'todos' ? 'Todos' : t}</button>`)
    .join('');
}

const card = (h) => `
  <button type="button" class="card" data-id="${h.id}" style="--cor:${h.cor};--on:${contraste(h.cor)}">
    ${selo(h)}
    <strong>${h.nome}</strong>
    <small>${h.real} · ${h.time}</small>
    <div class="barra" title="Poder total ${poderTotal(h)} de 50"><span style="width:${poderTotal(h) * 2}%"></span></div>
  </button>`;

function renderGrade() {
  const lista = filterHeroes(heroes, estado);
  $('#grade').innerHTML = lista.length
    ? lista.map(card).join('')
    : '<p class="vazio">Nenhum herói encontrado. Limpe a busca ou escolha outro time.</p>';
}

function abrirFicha(id) {
  const h = heroes.find((x) => x.id === id);
  const atributos = STATS.map((k) => `
    <div class="atributo" style="--cor:${h.cor}">
      <span>${ROTULOS[k]}</span><div class="barra"><span style="width:${h.stats[k] * 10}%"></span></div><b>${h.stats[k]}</b>
    </div>`).join('');
  $('#ficha').innerHTML = `
    <form method="dialog"><button class="fechar" aria-label="Fechar ficha">×</button></form>
    ${selo(h)}
    <h3>${h.nome}</h3>
    <p class="real">${h.real} · ${h.time}</p>
    <p>${h.bio}</p>
    <ul class="poderes">${h.poderes.map((p) => `<li>${p}</li>`).join('')}</ul>
    ${atributos}
    <p class="meta">Estreia: ${h.estreia}, em ${h.revista}.</p>`;
  $('#ficha').showModal();
}

$('#contagem').textContent = `${heroes.length} heróis em ${listTimes(heroes).length} times`;
$('#busca').addEventListener('input', (e) => { estado.busca = e.target.value; renderGrade(); });
$('#times').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  estado.time = b.dataset.time; renderTimes(); renderGrade();
});
$('#grade').addEventListener('click', (e) => {
  const c = e.target.closest('.card'); if (c) abrirFicha(c.dataset.id);
});
$('#ficha').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });

renderTimes();
renderGrade();
