import { perguntas } from './questions.js';
import { pontuar, mensagemFinal } from './quiz-logic.js';

const palco = document.querySelector('#palco');
let atual = 0, respostas = [], respondida = false;

function mostrarPergunta() {
  const p = perguntas[atual];
  respondida = false;
  palco.innerHTML = `
    <p class="progresso">Pergunta ${atual + 1} de ${perguntas.length}</p>
    <h2>${p.pergunta}</h2>
    <div class="opcoes">${p.opcoes.map((o, k) => `<button type="button" class="opcao" data-k="${k}">${o}</button>`).join('')}</div>
    <p class="feedback" aria-live="polite"></p>`;
}

function mostrarResultado() {
  const r = pontuar(perguntas, respostas);
  palco.innerHTML = `
    <p class="progresso">Fim do quiz</p>
    <p class="placar-final">Você acertou ${r.acertos} de ${r.total}</p>
    <p>${mensagemFinal(r.percentual)}</p>
    <button type="button" class="acao" data-acao="reiniciar">Jogar de novo</button>`;
}

palco.addEventListener('click', (e) => {
  const opcao = e.target.closest('.opcao');
  if (opcao && !respondida) {
    respondida = true;
    const k = Number(opcao.dataset.k), certa = perguntas[atual].correta;
    respostas[atual] = k;
    palco.querySelectorAll('.opcao').forEach((b, i) => {
      b.disabled = true;
      if (i === certa) b.classList.add('certa');
      else if (i === k) b.classList.add('errada');
    });
    palco.querySelector('.feedback').textContent = k === certa ? 'Isso mesmo!' : `Não foi dessa vez. A resposta certa: ${perguntas[atual].opcoes[certa]}.`;
    palco.insertAdjacentHTML('beforeend', `<button type="button" class="acao" data-acao="proxima">${atual === perguntas.length - 1 ? 'Ver resultado' : 'Próxima pergunta'}</button>`);
    palco.querySelector('[data-acao=proxima]').focus();
  }
  const acao = e.target.dataset.acao;
  if (acao === 'proxima') { atual += 1; atual < perguntas.length ? mostrarPergunta() : mostrarResultado(); }
  if (acao === 'reiniciar') { atual = 0; respostas = []; mostrarPergunta(); }
});

mostrarPergunta();
