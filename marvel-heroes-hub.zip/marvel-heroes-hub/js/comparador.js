import { heroes } from './heroes.js';
import { ranking, comparar, poderTotal, ROTULOS } from './logic.js';

const $ = (seletor) => document.querySelector(seletor);
const porId = (id) => heroes.find((h) => h.id === id);

$('#ranking').innerHTML = ranking(heroes, 5)
  .map((h) => `<li><span>${h.nome}</span><b>${poderTotal(h)}</b></li>`).join('');

const opcoes = heroes.map((h) => `<option value="${h.id}">${h.nome}</option>`).join('');
const selA = $('#heroiA'), selB = $('#heroiB');
selA.innerHTML = selB.innerHTML = opcoes;
selA.value = 'homem-de-ferro';
selB.value = 'capitao-america';

function render() {
  const a = porId(selA.value), b = porId(selB.value);
  const r = comparar(a, b);
  const linhas = r.linhas.map((l) => `
    <div class="linha">
      <span class="${l.vencedor === 'a' ? 'ganha' : ''}">${l.a}</span>
      <div class="duo esq"><i style="width:${l.a * 10}%"></i></div>
      <span>${ROTULOS[l.stat]}</span>
      <div class="duo"><i style="width:${l.b * 10}%"></i></div>
      <span class="${l.vencedor === 'b' ? 'ganha' : ''}">${l.b}</span>
    </div>`).join('');
  const veredito = r.vencedor === 'empate'
    ? 'Empate técnico no total de atributos.'
    : `${(r.vencedor === 'a' ? a : b).nome} leva a melhor no total.`;
  $('#resultado').innerHTML = `
    <div class="placar"><span>${a.nome}: ${r.totalA}</span><span>${b.nome}: ${r.totalB}</span></div>
    ${linhas}<p class="veredito">${veredito}</p>`;
}

selA.addEventListener('change', render);
selB.addEventListener('change', render);
render();
