// Funções puras: sem DOM, fáceis de testar com `node --test`.
export const STATS = ['forca', 'velocidade', 'inteligencia', 'resistencia', 'combate'];
export const ROTULOS = { forca: 'Força', velocidade: 'Velocidade', inteligencia: 'Inteligência', resistencia: 'Resistência', combate: 'Combate' };

export const normalizar = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export function filterHeroes(lista, { time = 'todos', busca = '' } = {}) {
  const q = normalizar(busca.trim());
  return lista.filter((h) =>
    (time === 'todos' || h.time === time) &&
    (!q || normalizar(`${h.nome} ${h.real}`).includes(q)));
}

export const listTimes = (lista) =>
  [...new Set(lista.map((h) => h.time))].sort((a, b) => a.localeCompare(b, 'pt'));

export const poderTotal = (h) => STATS.reduce((soma, k) => soma + h.stats[k], 0);

export function ranking(lista, n = 5) {
  return [...lista]
    .sort((a, b) => poderTotal(b) - poderTotal(a) || a.nome.localeCompare(b.nome, 'pt'))
    .slice(0, n);
}

export function comparar(a, b) {
  const linhas = STATS.map((k) => ({
    stat: k, a: a.stats[k], b: b.stats[k],
    vencedor: a.stats[k] === b.stats[k] ? 'empate' : a.stats[k] > b.stats[k] ? 'a' : 'b'
  }));
  const totalA = poderTotal(a), totalB = poderTotal(b);
  return { linhas, totalA, totalB, vencedor: totalA === totalB ? 'empate' : totalA > totalB ? 'a' : 'b' };
}

export const iniciais = (nome) =>
  nome.split(/[\s-]+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');

// Escolhe texto preto ou branco conforme a luminância do fundo (acessibilidade).
export function contraste(hex) {
  const n = parseInt(hex.slice(1), 16);
  const [r, g, b] = [n >> 16, (n >> 8) & 255, n & 255];
  return 0.299 * r + 0.587 * g + 0.114 * b > 150 ? '#000' : '#fff';
}
