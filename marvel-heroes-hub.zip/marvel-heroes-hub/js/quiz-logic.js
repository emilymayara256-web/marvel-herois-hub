export function pontuar(perguntas, respostas) {
  const acertos = perguntas.filter((p, i) => respostas[i] === p.correta).length;
  const total = perguntas.length;
  return { acertos, total, percentual: total ? Math.round((acertos / total) * 100) : 0 };
}

export function mensagemFinal(percentual) {
  if (percentual === 100) return 'Perfeito! Você é um Vingador de carteirinha.';
  if (percentual >= 60) return 'Muito bem! Falta pouco para virar lenda.';
  return 'Hora de reler os quadrinhos e tentar de novo.';
}
